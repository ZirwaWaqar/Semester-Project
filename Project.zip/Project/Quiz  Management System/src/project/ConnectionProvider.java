
package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

public class ConnectionProvider {
    public static Connection getcon()
    {
        try {
            Connection con; //variable con of type Connection
            String dbURL = "jdbc:postgresql://127.0.0.1:5432/umt";
            String userName = "postgres";
            String password = "zirwa";
            con = DriverManager.getConnection(dbURL, userName, password);
            
            return con;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
}
